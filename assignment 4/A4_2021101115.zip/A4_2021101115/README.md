# _*ASSIGNMENT 4 CPro*_
## _Adnan_
## _2021101115_
***
## This is a manual for the assignment 4 reports and codes for 2021101115
---
---
* Section 1:
    * Q1: The code can simply be compiled and run with no command line arguments.
    * Q2: The code can simply be compiled and run with no command line arguments.
    * Q3: The code can simply be compiled and run with no command line arguments.
* Section 2:
    * Q4A: Code can be compiled using `gcc 4a.c`, this code requires command line argument as `./a.out < name of file containing data > < name of file where mean is to be printed >`.
    * Q4B: The code for this question also calculates the variation of variance with N (starting from N=2), but it prints it in a file named `VarvsN.txt`. Code can be compiled using `gcc 4b.c`, this code requires command line argument as `./a.out < name of file containing data > < name of the file containing mean> < name of file where variance is to be printed >`.
    * Q4A: Code can be compiled using `gcc 4c.c`, this code requires command line argument as `./a.out < name of file containing data > < name of file where containing mean > < name of the file where percentage is to be printed >` .
* Section 3:
    * Q5A: The code can simply be compiled and run with no command line arguments.
    * Q5B: The code can simply be compiled and run with no command line arguments.
    * Q5C_ENCRYPT: Code can be compiled using `gcc 5c_encrypt.c`, this code requires command line argument as `./a.out < name of file containing message > < name of file where key is to be printed > < name of the file where encrypted message in binary is to be printed > `.
    * Q5C_DECRYPT: Code can be compiled using `gcc 5c_decrypt.c`, this code requires command line argument as `./a.out  < name of file where key was printed > < name of file containing encrypted message in binary> < name of the file where decrypted message is to be printed >` .
* Section 4:
    * Q6: The code can be compiled using `gcc 6.c`, code requires command line argument as `./a.out < name of the file which will contain character frequency > < name of the files containing texts (entered next to each other) >`.
    * Q7: The code can be compiled using `gcc 7.c`, code requires command line argument as `./a.out < name of the file which will contain string frequency > < name of all the files containing texts (entered next to each other) > `.
    * Q8: The code can be compiled using `gcc 8.c`, code requires command line argument as `./a.out < name of the file containing sorted names > < name of the second file containing sorted names > < name of the file which will contain sorted names combined >`.        
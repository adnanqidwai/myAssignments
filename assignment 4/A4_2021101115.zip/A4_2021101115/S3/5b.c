#include <stdio.h>
#include <stdlib.h>

const int n=1e6; int key[1000000];

int main()
{
    srand(10);
    
    int count0=0,count1=0,count0_0=0,count1_0=0,totalcount=0;
    for (int i = 0; i < 128; i++)
    {
        key[i]=rand()%2;
    }
    for (int i = 127; i < n; i++)
    {
        key[i]=key[i-1]^key[i-127];
    }
    for (int i = 127; i < n; i++)
    {
        if (key[i]==1)
        {
            count1++;
        }
        else
        {
            count0++;
        }
    }
    for (int i = 127; i < n-1; i++)
    {
        if (key[i+1]==0)
        {
            if (key[i]==0)
            {
                count0_0++;
            }
            else
            {
                count1_0++;
            }
            totalcount++;
        }
        
        
    }
    printf("\nusing XOR:\np(x=0|y=0): %lf p(x=0|y=1): %lf\n\n",(double)count0_0/count0,(double)count1_0/count1);
    count0_0=0;count1_0 =0;
    count0=0;count1=0;
    for (int i = 127; i < n; i++)
    {
        key[i]=rand()%2;
    }
    for (int i = 127; i < n; i++)
    {
        if (key[i]==1)
        {
            count1++;
        }
        else
        {
            count0++;
        }
    }
    for (int i = 127; i < n-1; i++)
    {
        if (key[i+1]==0)
        {
            if (key[i]==0)
            {
                count0_0++;
            }
            else
            {
                count1_0++;
            }
            totalcount++;
        }
        
    }
    printf("using rand():\np(x=0|y=0): %lf p(x=0|y=1): %lf\n",(double)count0_0/count0,(double)count1_0/count1)  ;  
    
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned char key[1000008],alphakey[125010];int n =1e6+8;

int main(int argc, char* argv[]){

    srand(10);
    unsigned char ch;
    FILE *ptr=fopen(argv[1],"r");
    FILE *keyptr =fopen(argv[2],"w");
    FILE *ptr3=fopen(argv[3],"w");

    for (int i = 0; i < 127; i++)
    {
        fprintf(keyptr,"%d",key[i]=rand()%2);    
    }
    for (int i = 127; i < n; i++)
    {
        key[i]=key[i-1]^key[i-127];
    }

    for (int i = 127,j=0; i < n-(n%8); i=i+8,j++)
    {
        alphakey[j]=((key[i]*128)+(key[i+1]*64)+(key[i+2]*32)+(key[i+3]*16)+(key[i+4]*8)+(key[i+5]*4)+(key[i+6]*2)+(key[i+7]));
    }
    int numchars=0;
    for (int i = 0; (fscanf(ptr,"%c",&ch))!=EOF; i++)
    {
        if (ch<0)
        {
            ch=ch+256;
        }
        
        numchars++;
        int num= alphakey[i]^ch;
        // printf("%d ",num);
        int *arr=(int*)malloc(sizeof(int)*8);
        int i =7;
        for (int i = 0; i < 8; i++)
        {
            *(arr+i)=0;
        }
        while (num>0)
        {
            *(arr+i)=num%2;
            num=num/2;
            i--;
        }
        for (int i = 0; i < 8; i++)
        {
            fprintf(ptr3,"%d",*(arr+i));
        }
        free(arr);
    }
    printf(" %d ",numchars);
    fclose(ptr);
    fclose(ptr3);
    fclose(keyptr);
}


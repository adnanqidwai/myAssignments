
#include <stdio.h>
#include <stdlib.h>
const int n=1e6; int key[1000000];
int main(){
    srand(10);
    
    int count0=0,count1=0;
    for (int i = 0; i < 128; i++)
    {
        key[i]=rand()%2;
        
    }
    for (int i = 127; i < n; i++)
    {
        key[i]=key[i-1]^key[i-127];
    }
    for (int i = 0; i < n; i++)
    {
        if (key[i]==1)
        {
            count1++;
        }
        else
        {
            count0++;
        }
    }
    printf("Q1: using XOR:\np{x=0}:%lf p{x=1}:%lf\n",(double)count0/n,(double)count1/n);
    count0=count1=0;
    for (int i = 127; i < n; i++)
    {
        key[i]=rand()%2;
    }
    for (int i = 0; i < n; i++)
    {
        if (key[i]==1)
        {
            count1++;
        }
        else
        {
            count0++;
        }
    }
    printf("Q1: using rand() :\np{x=0}:%lf p{x=1}:%lf\n",(double)count0/n,(double)count1/n);
}
#include <stdio.h>
#include <math.h>
#include <string.h>

unsigned char tempkey[1000008],alphakey[125010],encryptedchar[125010];int n =1e6+8;

int main(int argc, char* argv[]){

    char ch;
    FILE *tempkeyptr =fopen(argv[1],"r");
    FILE *ptr2=fopen(argv[2],"r");
    
    FILE *ptr3=fopen(argv[3],"w");

    for (int i = 0; i < 127; i++)
    {
        tempkey[i]= fgetc(tempkeyptr) -'0' ;
    }
    for (int i = 127; i < n; i++)
    {
        tempkey[i]=tempkey[i-1]^tempkey[i-127];
    }
    
    for (int i = 127,j=0; i < n-(n%8); i=i+8,j++)
    {
        alphakey[j]=((tempkey[i]*128)+(tempkey[i+1]*64)+(tempkey[i+2]*32)+(tempkey[i+3]*16)+(tempkey[i+4]*8)+(tempkey[i+5]*4)+(tempkey[i+6]*2)+(tempkey[i+7]));
    }
    int num=0;
    for (int i = 0; (ch=fgetc(ptr2))!=EOF; i++)
    {
        tempkey[i]=ch-'0';
        num++;
    }
    
    int numenc=0;
    for (int i = 0,j=0; i < num; i=i+8,j++)
    {
        encryptedchar[j]=((tempkey[i]*128)+(tempkey[i+1]*64)+(tempkey[i+2]*32)+(tempkey[i+3]*16)+(tempkey[i+4]*8)+(tempkey[i+5]*4)+(tempkey[i+6]*2)+(tempkey[i+7]));
        numenc++;
    }
    for (int i = 0; i < numenc; i++)
    {
        ch= alphakey[i]^encryptedchar[i];
        fprintf(ptr3,"%c",ch);
    }
    
    fclose(ptr2);
    fclose(ptr3);
    fclose(tempkeyptr);
}


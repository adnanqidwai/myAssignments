#include <stdio.h>

//format : ./a.out Q6ans.txt file_1.txt file_2.txt file_3.txt...file_x.txt

int main(int argc, char*argv[]){
    int a[256]={0};char ch;
    if (argc!=5)
    {
        printf("enter valid arguments");
        return -1;
    }
    FILE* fptr = fopen(argv[1],"w");
    FILE* ptr[argc-2];
    for (int i = 1; i < argc-1; i++)
    {
        ptr[i] = fopen(argv[i+1],"r");
        while ((ch=fgetc(ptr[i]))!=EOF)
        {
            a[ch]++;
        }
        fclose(ptr[i]);
    }
    
    for (int i = (int)'0'; i <=(int)'9'; i++)
    {
        fprintf(fptr,"%c:%d\n",i,a[i]);   
    }
    for (int i = (int)'A'; i <=(int)'Z'; i++)
    {
        fprintf(fptr,"%c:%d\n",i,a[i]);   
    }
    for (int i = (int)'a'; i <=(int)'z'; i++)
    {
        fprintf(fptr,"%c:%d\n",i,a[i]);   
    }
    fclose(fptr);
    
}
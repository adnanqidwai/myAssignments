#include <stdio.h>
#include <string.h>

//format: ./a.out q7ans.txt file_1.txt file_2.txt file_3.txt...file_x.txt

int main(int argc,char* argv[]){
    
    char temp[21],s[1001][21];
    int frequency[1001]={0};
    FILE*fptr1=fopen(argv[1],"w+");
    FILE*fptr2=fopen("q7_combined.txt","w+");
    FILE* ptr[argc -2];
    for (int i = 1; i < argc-1; i++)
    {
        ptr[i]=fopen(argv[i+1],"r");
        for (int j = 0; fscanf(ptr[i],"%s",s[j])!=EOF; j++)
        {
            fprintf(fptr2,"%s\n",s[j]);
        }
        fclose(ptr[i]);
    }
    rewind(fptr2);
    int nwords=0;
    for (int i = 0; fscanf(fptr2,"%s",s[i])!=EOF; i++)
    {
        nwords++;
    }
    for(int i=0; i<nwords; i++)
    {
        for(int j=0; j<nwords-1-i; j++)
        {
            if(strcmp(s[j], s[j+1]) > 0)
            {
                strcpy(temp, s[j]);
                strcpy(s[j], s[j+1]);
                strcpy(s[j+1], temp); 
            }
        }
    }
    rewind(fptr2);
    for (int i = 0; i < nwords; i++)
    {
        fprintf(fptr2,"%s\n",s[i]);
    }
    frequency[0]=1;
    int total=nwords;
    for (int i = 1; i<nwords; i++)
    {
        if (i==total)
        {
            break;
        }
        if (strcmp(s[i],s[i-1])==0)
        {
            frequency[i-1]++;total--;i--;
            for (int j = i; j < total; j++)
            {
                strcpy(s[j],s[j+1]);
            }
        }
        else
        {
            frequency[i]++;
        }
    }
    for (int i = 0; i < total; i++)
    {
        fprintf(fptr1,"%s:%d\n",s[i],frequency[i]);    
    }
    fclose(fptr1);
    fclose(fptr2);
}
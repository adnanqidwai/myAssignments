#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char all[2000000][16];
char s1[1000000][16];    
char s2[1000000][16];
int main(int argc,char *argv[]){
    int n1=0,n2=0;
    char temp[16];
    
    FILE *ptr1=fopen(argv[1],"r+");

    
    for (int i = 0; fscanf(ptr1,"%s",temp)==1;i++)
    {
        strcpy(s1[i],temp);
        n1++;
    }

    fclose(ptr1);

    FILE *ptr2=fopen(argv[2],"r+");
    
    for (int i = 0; fscanf(ptr2,"%s",temp)==1;i++)
    {
        strcpy(s2[i],temp);
        n2++;
    }

    fclose(ptr2);

    FILE *ptr3=fopen(argv[3],"w");

    int i = 0,j = 0,k = 0;
    while (i < n1 && j < n2) {
        if (strcmp(s1[i],s2[j])<=0) {
            strcpy(all[k],s1[i]);
            i++;
        }
        else {
            strcpy(all[k],s2[j]);
            j++;
        }
        k++;
    }
    while (i < n1) {
        strcpy(all[k],s1[i]);
        i++;
        k++;
    }
    while (j < n2) {
        strcpy(all[k],s2[j]);
        j++;
        k++;
    }    
    for (int i = 0; i < n2+n1; i++)
    {
        fprintf(ptr3,"%s\n",all[i]);
    }

    fclose(ptr3);
}
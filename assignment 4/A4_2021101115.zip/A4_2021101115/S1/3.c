#include <stdio.h>
#include <stdlib.h>


int main(){
    srand(10);
    FILE *ptr= fopen("nvspi.txt","w");
    long int x=0,n; double xcor,ycor,origdist;
    for(int j=1;j<=1e9;j=j*10){   
        long int x=0;
        for (int i = 0; i < j; i++)
        {
            xcor= ((double)rand()/(RAND_MAX));
            ycor= ((double)rand()/(RAND_MAX));
            origdist = ((xcor*xcor)+(ycor*ycor));
            if (origdist<=1)
            {
                x++;
            }
        }
        double pi= 4.0*x/j;
        fprintf(ptr,"%lf\n",pi);
    }    
}
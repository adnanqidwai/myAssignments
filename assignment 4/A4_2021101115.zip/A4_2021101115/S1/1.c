#include <stdio.h>
#include <stdlib.h>

int main(){
    srand(10);
    FILE *ptr= fopen("q1.txt","w");
    int arr[6]={0},x=0;
    for (int i = 0; i < 1e6; i++)
    {
        arr[rand()%6]++;
    }
    for (int i = 0; i < 6; i++)
    {
        fprintf(ptr,"%d\n",arr[i]);
    }
    
}
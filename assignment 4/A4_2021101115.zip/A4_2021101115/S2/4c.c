#include <stdio.h>


int main(int argc, char* argv[]){
    int total=0,lying=0;
    float temp,perc,mean;
    FILE *ptr = fopen(argv[1],"r");
    FILE *ptr2 = fopen(argv[2],"r");
    FILE *ptr3 = fopen(argv[3],"w");
    fscanf(ptr2,"%f",&mean);
    for (int n=1;fscanf(ptr,"%f",&temp)==1;n++)
    {   
        total=n;
        if (temp>=(0.8*mean)&&temp<=(1.2*mean))
        {
            lying++;
        }
        
    }
    perc= (double)lying/(total)*100;
    fprintf(ptr3,"%f",perc);
}
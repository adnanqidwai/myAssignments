#include <stdio.h>


int main(int argc, char* argv[]){
    double avg=0,temp,sum=0,sum_sq=0,diff_sq=0,variable_var=0;
    int count=0;
    FILE *ptr =fopen(argv[1],"r");
    FILE *ptr2 =fopen(argv[2],"r");
    FILE *ptr3 =fopen(argv[3],"w");
    FILE *ptr4 =fopen("VarvsN.txt","w");
    for (int n=1;fscanf(ptr,"%lf",&temp)!=EOF;n++)
    {   
        count=n;
        sum = sum + temp;
        sum_sq= sum_sq +(temp*temp);
        avg= sum/n;
        diff_sq= diff_sq + (temp-avg)*(temp-avg);
        if(n!=1){
            fprintf(ptr4,"%lf\n",(sum_sq-(sum*sum/n))/n-1);
        }
    }
    double var = (sum_sq/(double)count) -(avg*avg);
    fprintf(ptr3,"%lf",var);
    fclose(ptr);
    fclose(ptr2);
    fclose(ptr3);
}